# AnantPlay Sinhala Subtitle Bridge — v2 (real-HTTP .srt delivery)

Zero-fork companion for [AnantPlay](https://github.com/AnantPlay/android) (official v2.23.1, commit
`be74df2`): search, machine-translate (EN→SI with a free Gemini key) or upload Sinhala subtitles and
hand AnantPlay's **native player** a REAL HTTP 200 `.srt` URL — never a Service-Worker ghost URL
that 404s inside ExoPlayer.

## Quick start
- **Cloudflare (free)**: `wrangler kv namespace create SUBS_KV` → paste the id in `wrangler.toml` →
  `wrangler deploy` → register `https://<worker>/index.json` inside AnantPlay → Settings → Sources.
- **LAN / Termux (zero cloud)**: `python3 local-server/server.py` → register
  `http://<LAN-IP>:8765/index.json`.

## Repo map
| Path | What |
| --- | --- |
| `worker/src/index.js` | the Cloudflare Worker: Bridge UI + `/api/*` + real `/sub/<token>.srt` |
| `local-server/server.py` | pure-stdlib LAN server, the same endpoints on port 8765 |
| `bridge-ui/public/` | the Bridge page (deeplink auto-fill, search, translate, upload, 3 handoff modes) |
| `pr-patch/` | two `git apply --check`-verified upstream patches (`be74df2`) |
| `tests/` | worker tests (41), fixture tests (18), real-HTTP e2e (15) — all green |
| `docs/` | `REPORT.md` (architecture + verification logs), `SETUP-EN.md`, `SETUP-SI.md` |

## Verify everything yourself
```bash
node tests/run-all.js                          # 59 PASS / 0 FAIL
python3 -m unittest discover -s tests -p 'local_server_test.py' -v   # 15 OK (real HTTP 200 .srt)
git clone https://github.com/AnantPlay/android && cd android
git apply --check ../pr-patch/01-subdl-provider.patch   # ✅
git apply --check ../pr-patch/02-local-srt-picker.patch  # ✅
```

Licensed under the repository's own terms; the subtitle fixtures in `tests/fixtures/` are
**synthetic Sinhala text** (no copyrighted subtitle content ships with this repo).
