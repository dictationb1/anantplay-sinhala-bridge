# SETUP (EN) — AnantPlay Sinhala Subtitle Bridge v2

Two hosting modes; pick ONE. Both serve the **same real HTTP 200 `.srt` URLs** that fix the v1
404-on-ExoPlayer bug. No fork of AnantPlay is required for any of this — the app is used exactly
as released.

---

## Mode A — Cloudflare Worker (recommended, free tier, ~10 minutes)

### 1 · Prerequisites
- A free Cloudflare account (workers.dev subdomain included).
- Node 18+ and the wrangler CLI: `npm install -g wrangler`, then `wrangler login`.

### 2 · Deploy the worker
```bash
cd anantplay-si-subs-bridge          # the repo root from this zip
wrangler kv namespace create SUBS_KV # copy the printed id
```
Paste that id into `wrangler.toml` replacing `REPLACE_WITH_YOUR_KV_NAMESPACE_ID`, then:
```bash
wrangler deploy
```
Your bridge is live at `https://anantplay-si-subs-bridge.<your-subdomain>.workers.dev/`.

### 3 · Verify (30 seconds)
```bash
curl -s https://<your-worker>/index.json        # sources: sites + deeplinks (live host, no YOUR-HOST)
curl -s -X POST https://<your-worker>/api/publish-srt \
     -H 'Content-Type: application/json' \
     -d '{"text":"1\n00:00:01,000 --> 00:00:02,000\nආයුබෝවන්\n"}'
curl -sI https://<your-worker>/sub/<token>.srt # HTTP/1.1 200 · application/x-subrip; charset=utf-8
```

### 4 · Register inside AnantPlay
AnantPlay → Settings → Sources → Add index → paste
`https://<your-worker>/index.json`. (Or add the Bridge itself as a site and open it from the app.)

### 5 · Play something
1. From AnantPlay's Movies/TV **Title Links**, open your Bridge — the movie/episode auto-fills
   (`/deeplinks.json` maps it) and Sinhala subtitle search runs with zero typing.
2. Pick a subtitle (OpenSubtitles / SubDL with your key / piratelk hint) → or translate an English
   one to Sinhala with your free Gemini key (aistudio.google.com) → or upload a `.srt`/`.zip` you
   downloaded from Baiscope/Zoom.
3. The Bridge shows the **real `.srt` URL** and fetches it once (so the Sniffer captures it).
4. Hand off the stream: paste a direct `.m3u8`/`.mp4` URL (try the built-in **Mux public HLS
   demo** button first — 1-click proof), or load your own embed-player template (Mode 2), or just
   play and pick "Subtitles → 📁 Open local .srt…" if you use the upstream patch below.
5. AnantPlay's native player plays the stream with the Sinhala subtitle as a real track.

---

## Mode B — LAN / Termux (zero cloud, one command)

AnantPlay allows cleartext HTTP (`AndroidManifest.xml:19` `android:usesCleartextTraffic="true"`),
so a phone/PC on the same Wi-Fi works directly.

```bash
cd anantplay-si-subs-bridge
python3 local-server/server.py          # binds 0.0.0.0:8765, prints the LAN URL
# e.g.  SiBridge local server → http://192.168.1.20:8765/  (LAN) · http://127.0.0.1:8765/
```
Termux: `pkg install python` first; then the same command (run with `termux-wake-lock` for
long sessions).

Register inside AnantPlay exactly like Mode A but with `http://<LAN-IP>:8765/index.json`.
Everything else is identical: the API routes, the real `/sub/<token>.srt` (24 h TTL, SHA-256
dedupe), the Bridge UI. The subtitle storage is the plain `local-server/subs/` folder — delete it
any time to reset.

> Note: OpenSubtitles/SubDL search from the LAN server requires outbound internet from the host;
> translation needs your Gemini key either way. If the host is offline, upload mode still works.

---

## Optional upstream patches (for AnantPlay contributors)

Two `git apply`-ready patches against `AnantPlay/android` @ `be74df2` live in `pr-patch/`:

- **01-subdl-provider.patch** — adds SubDL as a subtitle provider (Settings key + merge into
  OpenSubtitles results + `test/SubDlTest.java`).
- **02-local-srt-picker.patch** — adds "📁 Open local .srt…" to the player's subtitle sheet
  (`ACTION_OPEN_DOCUMENT`, UTF-8 normalization through the existing SubFetch path).

```bash
git clone https://github.com/AnantPlay/android && cd android
git apply --check ../anantplay-si-subs-bridge/pr-patch/01-subdl-provider.patch   # ✅
git apply ../anantplay-si-subs-bridge/pr-patch/01-subdl-provider.patch
git apply ../anantplay-si-subs-bridge/pr-patch/02-local-srt-picker.patch
```

They are OPTIONAL: the Bridge works with the released APK as-is.

---

## Troubleshooting

| Symptom | Fix |
| --- | --- |
| `/api/*` returns "KV not bound" | `wrangler kv namespace create SUBS_KV` and paste the id in `wrangler.toml` (Mode A only) |
| Subtitles don't attach | Tap **URL එක fetch කරන්න** on the Bridge so the Sniffer sees the real request BEFORE handing off the stream |
| Sinhala text looks broken | The pipeline stores BOM-less UTF-8; if a source file is in another legacy encoding, re-save it as UTF-8 and upload again |
| Gemini batch stalls | Free-tier rate limit — wait a minute; batches resume automatically (timestamp-validated) |
| LAN mode unreachable | Same Wi-Fi, and check the phone's "private address" Wi-Fi setting isn't isolating clients |
