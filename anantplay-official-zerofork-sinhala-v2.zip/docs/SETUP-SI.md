# SETUP (සිංහල) — AnantPlay සිංහල උපසිරැසි පාලම v2

මෙය AnantPlay එක **කැපගසා නොවී** (zero-fork) සිංහල උපසිරැසි ලබා දෙන පාලක පිටුවයි. v1 හි තිබූ
මාරාන්තික දෝෂය (ExoPlayer එකට `.srt` ලැබුණේ HTTP 404 ලෙස) මෙන්න මෙය නිවැරදි කර ඇත: සෑම
උපසිරැසියක්ම **ඇත්ත HTTP 200 `.srt` URL** එකකින් ලැබේ — Service Worker එකක් කොහෙවත් නැහැ.

සත්කාරණ ආකාර දෙකක් තිබේ; එකක් තෝරන්න.

---

## ආකාරය A — Cloudflare Worker (නොමිලේ, තැපෑල ~10 මිනිත්තු)

### 1 · අවශ්‍ය දේ
- නොමිලේ Cloudflare ගිණුමක් (workers.dev උප-වසම නොමිලේ ලැබේ).
- Node 18+ සහ wrangler: `npm install -g wrangler` → `wrangler login`.

### 2 · Worker එක deploy කරන්න
```bash
cd anantplay-si-subs-bridge
wrangler kv namespace create SUBS_KV      # print වන id එක copy කරන්න
```
ඒ id එක `wrangler.toml` හි `REPLACE_WITH_YOUR_KV_NAMESPACE_ID` තැනට paste කර, ඊට පස්සේ:
```bash
wrangler deploy
```
පාලම දැන් `https://anantplay-si-subs-bridge.<ඔබේ-වසම>.workers.dev/` හි සජීවීයි.

### 3 · තත්පර 30කින් පරීක්ෂා කරන්න
```bash
curl -s https://<worker>/index.json       # sites + deeplinks දෙකම (live host එකෙන්ම)
curl -s -X POST https://<worker>/api/publish-srt -H 'Content-Type: application/json' \
     -d '{"text":"1\n00:00:01,000 --> 00:00:02,000\nආයුබෝවන්\n"}'
curl -sI https://<worker>/sub/<token>.srt # HTTP 200 · application/x-subrip; charset=utf-8
```

### 4 · AnantPlay එකට ලියාපදිංචි කරන්න
AnantPlay → Settings → Sources → Add index → `https://<worker>/index.json` paste කරන්න.

### 5 · බලන්න
1. AnantPlay Movies/TV **Title Links** වලින් පාලම අසුරන්න — චිත්‍රපටි/කථාංගය ස්වයංක්‍රීයව පිරෙනවා,
   සිංහල සෙවීම කැඳවුණු පටන්ම ද ය ලිවිය ඕනි නැහැ.
2. උපසිරැසියක් තෝරන්න (OpenSubtitles / SubDL / piratelk), නැත්නම් ඉංග්‍රීසි එකක් ඔබේ නොමිලේ
   Gemini key එකෙන් සිංහලට පරිවර්තන්න, නැත්නම් Baiscope/Zoom වලින් බාගත කළ `.srt/.zip` එක upload කරන්න.
3. පාලම **ඇත්ත `.srt` URL** එක පෙන්වනවා — එය එක පාරක් fetch කරනවා (Sniffer එකට පෙනෙන්න).
4. වීඩියෝ ධාරාව අතහැරලා දෙන්න: `.m3u8/.mp4` URL එකක් කෙලින්ම (පළමුව **Mux ප්‍රසිද්ධ HLS demo**
   බොත්තම තත්පර 1කින් පරීක්ෂාවට), නැත්නම් ඔබේම embed player template එකක් (Mode 2), නැත්නම්
   upstream patch එක යොදා ඇත්නම් "📁 Open local .srt…" මෙනුවෙන්.
5. AnantPlay native player එක වීඩියෝව ධාරාවෙන්ම + සිංහල උපසිරැසිය ඇත්ත track එකක් ලෙස දර්ශනය කරයි.

---

## ආකාරය B — LAN / Termux (වලාකුල් නැහැ, විධානය 1කින්)

AnantPlay cleartext HTTP වලට ඉඩ දෙනවා (`AndroidManifest.xml:19`), ඒ නිසේ එකම Wi-Fi එකේ
දුරකථන/PC එකකින් කෙලින්ම වැඩ:

```bash
cd anantplay-si-subs-bridge
python3 local-server/server.py          # 0.0.0.0:8765 — LAN URL එක print වේ
# උදා: SiBridge local server → http://192.168.1.20:8765/  (LAN) · http://127.0.0.1:8765/
```
Termux: `pkg install python` කරලා ඒ විධානයම (දිගු සැසි සඳහා `termux-wake-lock`).

AnantPlay එකට ලියාපදිංචි කරන්න: `http://<LAN-IP>:8765/index.json`. අනෙක් සියලු දේ එකසේමයි —
API මාර්ග, ඇත්ත `/sub/<token>.srt` (පැය 24 TTL, SHA-256 dedupe), පාලම UI. උපසිරැසි ගබඩාව
`local-server/subs/` සරල බහාලුමයි — කැමති වෙලාවක delete කරලා නැවත පටන් ගන්න.

>සටහන: LAN සේවාකයෙන් OpenSubtitles/SubDL සෙවීමට අන්තර්ජාලය අවශ්‍යයි; පරිවර්තනයට ඔබේ Gemini
>key එක ඕනිම. අන්තර්ජාලය නැති විටත් upload ආකාරය වැඩ කරයි.

---

## අභ්‍යාස ලේඛන (upstream patches — AnantPlay දායකයන්ට පමණි)

`pr-patch/` තුළ `be74df2` ට එරෙහි `git apply --check` ✅ සහිත patch දෙකක්:

- **01-subdl-provider.patch** — SubDL සැපයුම්කරුවා (Settings key එක + OpenSubtitles වලට එකතු වීම).
- **02-local-srt-picker.patch** — ධාවකයේ උපසිරැසි මෙනුවට "📁 Open local .srt…" (ACTION_OPEN_DOCUMENT).

```bash
git clone https://github.com/AnantPlay/android && cd android
git apply --check …/pr-patch/01-subdl-provider.patch     # ✅
git apply …/pr-patch/01-subdl-provider.patch
git apply …/pr-patch/02-local-srt-picker.patch
```

ඒවා අභ්‍යාස මිස අනිවාර්ය නොවේ: පාලම නිකුත් කළ APK එකෙන්ම වැඩ කරයි.

---

## ගැටලු නිරාකරණය

| රෝග ලක්ෂණය | ප්‍රතිකාරය |
| --- | --- |
| `/api/*` "KV not bound" කියයි | `wrangler kv namespace create SUBS_KV` → id එක `wrangler.toml` එකට (ආකාරය A) |
| උපසිරැසි ගැලපෙන්නේ නැහැ | ධාරාව අතහැරලා දෙන්නට කලින් පාලමේ **URL එක fetch කරන්න** බොත්තම ඔබන්න (Sniffer එකට ඇත්ත request එක පෙනෙන්න) |
| සිංහල අකුරු කැඩිලා පේනවා | පයිප්ලයිනය BOM-නැති UTF-8 ගබඩා කරයි; ප්‍රභවය legacy encoding එකක නම් නැවත UTF-8 ලෙස save කරලා upload කරන්න |
| Gemini batch එක නතර වෙනවා | නොමිලේ-මටේ rate limit — මිනිත්තුවක් රැඳී සිටින්න; batches ස්වයංක්‍රීයව නැවත අරඹයි (timestamps සත්‍යාපනය සමඟ) |
| LAN එක හමු නොවේ | එකම Wi-Fi, දුරකථනයේ "private address" (Wi-Fi සැකසුම) සේවාලභ්දාග්‍රහණයන් හුදෙකලා නැද්ද බලන්න |
