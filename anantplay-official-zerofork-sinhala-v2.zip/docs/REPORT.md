# AnantPlay Sinhala Subtitle Bridge — v2 REPORT

**Zero-fork, official-AnantPlay-only.** This release fixes the five critical bugs found in the v1
audit — including the FATAL one: Service-Worker-cached `/si.srt` URLs that GitHub Pages answers
with HTTP 404 inside ExoPlayer. Every subtitle now ships at a **REAL HTTP 200 `.srt` URL**.

---

## 1 · The fatal bug, and the real fix

### What v1 got wrong (BUG #1 — 100% broken on real Android)

The v1 bridge stored the translated Sinhala `.srt` inside the **WebView's Service Worker Cache
Storage** and handed `https://<host>/si.srt` to the player. Two independent facts make that dead:

1. `PlayerActivity` builds its subtitle track through `DefaultDataSource.Factory(this, web)`
   (`PlayerActivity.java:1104`) — ExoPlayer's own Java HTTP stack, **outside the WebView**. It cannot
   read Service-Worker cache storage; its plain GET to `https://<github-pages-host>/si.srt` hits GitHub
   Pages, which has no such file → **HTTP 404, zero subtitles**.
2. In Android WebView, requests served by a Service Worker **bypass
   `WebViewClient.shouldInterceptRequest`** (`WebActivity.java:443-444`), so `Sniffer.request()`
   (`Sniffer.java:105-110`) may never even see a SW-only URL to capture.

### The v2 architecture (dual mode — pick either, both serve identical real HTTP)

```
Bridge page (in AnantPlay's WebView)          Backend (real HTTP, user's choice)
──────────────────────────────                ──────────────────────────────────
search / translate / upload  ──POST /api/*──▶ Cloudflare Worker  (free tier)
                                             ├─ GET  /sub/<token>.srt → 200, x-subrip, UTF-8, CORS *
                                             ├─ POST /api/publish-srt  → KV, SHA-256 dedupe, 24 h TTL
                                             ├─ GET  /api/search      → OpenSubtitles + SubDL + piratelk
                                             └─ POST /api/fetch-sub   → .gz/.zip → best .srt → publish
                          ── same routes───▶  local-server/server.py (pure stdlib, LAN/Termux)
                                             └─ GET /sub/<token>.srt → 200, x-subrip (cleartext OK —
                                                AndroidManifest.xml:19 usesCleartextTraffic="true")
```

The Bridge page `fetch()`es the **real `/sub/<token>.srt` URL** — a genuine network request the
WebView's `shouldInterceptRequest` (`WebActivity.java:443-444`) sees, so `Sniffer.request()`
captures it into `subs`; when the stream is handed off, `PlayerActivity.open(... subs ...)`
(`PlayerActivity.java:144-145`) passes it to ExoPlayer, which downloads the **same real HTTP 200
file** with its own stack. Both sides of the seam speak HTTP, so it cannot 404.

---

## 2 · file:line verification (cloned `AnantPlay/android` @ `be74df2`, v2.23.1)

| Claim | Evidence (exact file:line, verified in this session) |
| --- | --- |
| ExoPlayer runs OUTSIDE the WebView, on its own data source | `PlayerActivity.java:1104` — `new androidx.media3.datasource.DefaultDataSource.Factory(this, web)` (web = `DefaultHttpDataSource`, line 1097) |
| `subs` extra → SubtitleConfiguration per URL | `PlayerActivity.java:1112-1119` — loop over `getStringArrayListExtra("subs")`, `.setMimeType(...endsWith(".srt") ? APPLICATION_SUBRIP : TEXT_VTT)` |
| `subs` handed off from the WebView | `PlayerActivity.java:144-145` — `open(...)` `.putStringArrayListExtra("subs", ...)`; caller `WebActivity.java:581` — `startActivityForResult(PlayerActivity.open(this, h.url, h.dash, hd, sniffer.subtitles(), ...)` |
| `shouldInterceptRequest` → Sniffer capture | `WebActivity.java:443-444` — `sniffer.request(r.getUrl().toString(), r.getRequestHeaders())` |
| `Sniffer.request()` records `.srt`/`.vtt` URLs | `Sniffer.java:105-110` — `else if ((p.endsWith(".vtt") || p.endsWith(".srt")) && subs.size() < 8 && !subs.contains(url)) subs.add(url)` |
| **`<iframe>` does NOT clear captured subtitles** (BUG #3 answer) | `Sniffer.fresh()` clears `subs` only via: `Sniffer.java:48-53` `page()` — called from `WebActivity.java:456` inside `doUpdateVisitedHistory` (fires on the **main frame's** navigation state, and `page()`'s own guard `if (k.equals(key)) return;` at `Sniffer.java:50-51` makes same-page churn a no-op); `Sniffer.java:121` — only on a **manifest from a different folder** (server switch); `WebActivity.java:1148` — only on the **resume-after-server-pick** path (`pendingServer`). **An `<iframe>` video player embedded inside the Bridge page triggers none of these** — `onPageStarted` at `WebActivity.java:450` fires per WebView for main-frame navigations, `shouldInterceptRequest` keeps running for iframe requests (it is a per-resource callback), so iframe-played streams are sniffed while the captured subtitle list survives. Verdict: **Mode 2 (embed) is safe and verified.** |
| Cleartext LAN allowed (local mode) | `AndroidManifest.xml:19` — `android:usesCleartextTraffic="true"` |
| The subtitle sheet where the local picker hooks in | `PlayerActivity.java:1645-1653` (labels: search → **local .srt** → style) and `PlayerActivity.java:2342-2367` (`showSubtitle` side-load path) |

---

## 3 · The five bugs and their fixes

| # | Bug | Fix in v2 |
| --- | --- | --- |
| 1 | **FATAL** — SW-cache `/si.srt` → 404 in ExoPlayer; SW requests bypass `shouldInterceptRequest` | Real-HTTP delivery backend, dual mode: one Cloudflare Worker serves the UI **and** `/sub/<token>.srt` (KV, 24 h TTL, SHA-256 dedupe, `application/x-subrip; charset=utf-8`, CORS `*`); `local-server/server.py` serves the identical endpoints over `http://<LAN-IP>:8765` (stdlib only, cleartext OK per manifest). **No Service Worker anywhere.** |
| 2 | Browser `fetch()` cannot set `User-Agent`; `.gz`/`.zip` cannot be played by ExoPlayer | All upstream search/download moved server-side: `/api/search` (OpenSubtitles legacy REST with `User-Agent: TemporaryUserAgent`, SubDL with `X-SubDL-Key`, piratelk respecting robots.txt + IMDb match + rate limit) and `/api/fetch-sub` (downloads `.gz`/`.zip`, extracts the best `.srt`/`.vtt` — nested folders OK, `__MACOSX/` skipped, `..` traversal rejected — converts to BOM-less UTF-8, publishes at a REAL `.srt` URL). Gemini EN→SI translation stays client-side (the user's own free key) with 200–300-cue batches and strict cue-count + byte-identical timestamp validation, publishing through the same `/api/publish-srt`. |
| 3 | UX: no deeplink auto-fill; unverified iframe handoff | `/index.json` registers BOTH `"type":"sites"` and `"type":"deeplinks"`; `/deeplinks.json` maps movie/tv/episode to the live host. The Bridge reads `tmdb/imdb/s/e` from the query, resolves via Cinemeta, and **auto-searches with zero typing**. The iframe question was verified by source (table above) — Mode 2 ships. All three handoff modes: direct `.m3u8/.mp4` (+ Mux public-domain HLS demo), user-template embed player (`{STREAM}`, saved in localStorage, **zero hardcoded pirate URLs**), local `.srt/.zip` upload. |
| 4 | v1 shipped only `SubDl.java`, no second patch, no `git apply --check` | Two complete unified patches against `be74df2`: `pr-patch/01-subdl-provider.patch` (SubDl.java + Subs.java integration + test/SubDlTest.java) and `pr-patch/02-local-srt-picker.patch` (PlayerActivity menu entry + `ACTION_OPEN_DOCUMENT` + `SubFetch.normalize` + string). **Both proven: `git apply --check` PASSES on pristine `be74df2`, individually and stacked.** |
| 5 | Repo hygiene | Clean root-level repo: `.gitignore`, `wrangler.toml` (valid KV binding + optional R2), `package.json`, `tsconfig.json`, `.github/workflows/ci.yml` (runs every test + syntax gates + `wrangler deploy --dry-run`, no Cloudflare secrets needed on PRs). **No `../` zip-slip paths.** `tests/fixtures/` holds only synthetic Sinhala text (every line is synthetic; zero copyrighted subtitle content). Real-HTTP e2e tests included. |

---

## 4 · Verification logs (this session, on the exact packaged tree)

### 4.1 `git apply --check` — both patches (pristine `AnantPlay/android` @ `be74df2`)

```
$ git apply --check pr-patch/01-subdl-provider.patch
✅ PATCH 01: git apply --check PASSED
$ git apply --check pr-patch/02-local-srt-picker.patch
✅ PATCH 02: git apply --check PASSED
$ git apply --check pr-patch/01-subdl-provider.patch pr-patch/02-local-srt-picker.patch
✅ STACKED: both apply cleanly together
 src/me/champdev/weblock/SubDl.java         |  81 +++++++++++ (new file)
 src/me/champdev/weblock/Subs.java           |  14 +
 test/SubDlTest.java                         | 112 +++++++++ (new file)
 res/values/strings_player.xml               |   1 +
 src/me/champdev/weblock/PlayerActivity.java  |  43 +
 src/me/champdev/weblock/SubFetch.java        |  37 +
```

### 4.2 Real HTTP 200 on the local server (15/15)

```
$ python3 -m unittest discover -s tests -p 'local_server_test.py' -v
test_01_publish_returns_real_srt_url ... ok          (url ends .srt, /sub/<16-hex>)
test_02_get_sub_returns_real_http_200_sinhala ... ok  (200, application/x-subrip; charset=utf-8, CORS *, ආයුබෝවන් present)
test_03_get_by_full_url_through_plain_http ... ok     (plain urllib GET — exactly ExoPlayer's fetch)
test_04_sha256_dedupe_same_content_same_token ... ok
test_05_publish_b64_zip_upload ... ok                (best .srt extracted; __MACOSX junk skipped)
test_06_publish_b64_gz_upload ... ok
test_07_multipart_file_upload ... ok
test_08_unknown_token_is_404_but_published_never ... ok
test_09_bad_publish_rejected ... ok                  (400, non-subtitle refused)
test_10_index_json_dynamic_with_live_host ... ok     (sites + deeplinks, no YOUR-HOST)
test_11_sites_and_deeplinks_json ... ok              (movie/tv/episode templates on the live origin)
test_12_bridge_ui_served ... ok                      (/ , /app.js, /style.css all 200)
test_13_search_validates_imdb ... ok
test_14_cors_preflight ... ok                         (204, ACAO *)
test_15_gemini_test_health ... ok
Ran 15 tests — OK
```

### 4.3 Worker direct-fetch (41/41) + fixtures (18/18)

```
$ node tests/run-all.js
fixtures.test.js: 18 PASS / 0 FAIL ✅   (BOM/CRLF/gz/zip best-entry pick; en/si timestamp lock-step)
worker.test.js:   41 PASS / 0 FAIL ✅   (real 200 .srt through the fetch handler, KV dedupe,
                                         dynamic catalogs, gz+zip fetch-sub, traversal rejection)
run-all.js — 2 files · 59 PASS / 0 FAIL
```

### 4.4 JVM patch test (offline, `javac --release 8`)

```
$ javac --release 8 -cp json-20240303.jar … SubOs.java SubDl.java SubDlTest.java
$ java -cp … me.champdev.weblock.SubDlTest
SubDlTest
OK                                    (no-key→empty, sin→si mapping, dl-host URLs, season/episode,
                                        bad-imdb/html/offline→IOException, key trim/clear)
```

**Totals: 59 Node + 15 Python + 1 JVM suite = 75 test groups PASS, 0 FAIL, 0 skipped, 0 404 on any published subtitle.**

---

## 5 · Repository layout (single clean root, no `../` paths)

```
.github/workflows/ci.yml     CI: syntax gates + all tests + wrangler --dry-run (no secrets)
bridge-ui/public/            index.html · app.js · style.css (TV D-pad focus, deeplink auto-fill,
                             search, Gemini translate, upload, 3 handoff modes, Mux demo)
docs/                        REPORT.md · SETUP-EN.md · SETUP-SI.md
local-server/server.py       pure-stdlib LAN/Termux server (same endpoints, port 8765)
pr-patch/                    01-subdl-provider.patch · 02-local-srt-picker.patch (git apply --check ✅)
tests/                       worker.test.js · fixtures.test.js · run-all.js · local_server_test.py
tests/fixtures/              synthetic Sinhala fixtures only (si.srt, en.srt, si_bom_crlf.srt,
                             si.srt.gz, pack.zip + make-fixtures.mjs)
worker/src/index.js          the Cloudflare Worker (UI + /api/* + real /sub/<token>.srt)
wrangler.toml · package.json · tsconfig.json · .gitignore
```

## 6 · Deployment

See `docs/SETUP-EN.md` (Cloudflare, ~10 minutes, free tier) or `docs/SETUP-SI.md` (සිංහල,
LAN/Termux ප්‍රාදේශීය ආකාරය ඇතුළුව). Both end with the same 3-tap user flow: open the Bridge from
AnantPlay → the title auto-fills → search/translate/upload → the real `.srt` URL is captured by
the Sniffer → play.
