/* AnantPlay Sinhala Subtitle Bridge — Cloudflare Worker v2 (real-HTTP .srt delivery).
 *
 * BUG #1 FIX: this worker serves the translated/processed UTF-8 .srt at REAL HTTP 200
 * URLs ending in .srt (/sub/<token>.srt), so ExoPlayer's DefaultDataSource — which runs
 * OUTSIDE the WebView and can NEVER read Service-Worker Cache Storage — fetches a real
 * file. The Bridge page fetch()es the same real URL first, so WebView's
 * shouldInterceptRequest (WebActivity.java:443-444) sees the genuine network request and
 * Sniffer.request() (Sniffer.java:105-110) captures it as a subtitle.
 *
 * BUG #2 FIX: /api/search and /api/fetch-sub run server-side (real User-Agent header —
 * forbidden in browser fetch), gunzip .gz and unzip .zip, pick the best .srt/.vtt entry
 * (nested folders OK, __MACOSX/ skipped, .. traversal rejected), convert to BOM-less
 * UTF-8 and publish at a real /sub/<token>.srt URL.
 *
 * Storage: Cloudflare KV, 24h TTL, SHA-256 deduplicated (token = first 16 hex of the
 * content hash — identical content re-publishes to the same URL).
 */

// ─────────────────────────────────────────────────────────────────────────────
// shared helpers (exported for tests via `export`)
// ─────────────────────────────────────────────────────────────────────────────

const TOKEN_LEN = 16; // hex chars of the SHA-256 used as the token
const TTL_SECONDS = 24 * 3600; // 24h KV TTL

function hexOf(bytes) {
  let out = '';
  for (let i = 0; i < bytes.length; i++) out += ('0' + bytes[i].toString(16)).slice(-2);
  return out;
}

async function sha256Hex(data) {
  const d = typeof data === 'string' ? new TextEncoder().encode(data) : new Uint8Array(data);
  const h = await crypto.subtle.digest('SHA-256', d);
  return hexOf(new Uint8Array(h));
}

/** True when bytes start with the gzip magic 1f 8b. */
function isGzip(bytes) {
  return bytes.length > 1 && bytes[0] === 0x1f && bytes[1] === 0x8b;
}

/** True when bytes start with the ZIP magic PK\x03\x04. */
function isZip(bytes) {
  return bytes.length > 3 && bytes[0] === 0x50 && bytes[1] === 0x4b && bytes[2] === 0x03 && bytes[3] === 0x04;
}

/** Parse a ZIP's central directory WITHOUT inflating entries (works on plain Uint8Array).
 * Returns [{name, compressedSize, uncompressedSize, localHeaderOffset}] — the reader
 * only needs names + sizes to pick the best entry; the actual inflate happens in
 * unzipBest() via DecompressionStream('deflate-raw'). */
function zipEntries(bytes) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const findEOCD = () => {
    for (let i = bytes.length - 22; i >= 0; i--) {
      if (bytes[i] === 0x50 && bytes[i + 1] === 0x4b && bytes[i + 2] === 0x05 && bytes[i + 3] === 0x06) {
        return i;
      }
    }
    return -1;
  };
  const eocd = findEOCD();
  if (eocd < 0) return [];
  let count = dv.getUint16(eocd + 8, true);   // EOCD+8: total entries on this disk
  let off = dv.getUint32(eocd + 16, true);
  const out = [];
  for (let n = 0; n < count; n++) {
    if (off + 46 > bytes.length) break;
    if (dv.getUint32(off, true) !== 0x02014b50) break; // central file header signature
    const method = dv.getUint16(off + 10, true);
    const csize = dv.getUint32(off + 20, true);
    const usize = dv.getUint32(off + 24, true);
    const nameLen = dv.getUint16(off + 28, true);
    const extraLen = dv.getUint16(off + 30, true);
    const commentLen = dv.getUint16(off + 32, true);
    const lho = dv.getUint32(off + 42, true);
    const name = new TextDecoder().decode(bytes.subarray(off + 46, off + 46 + nameLen));
    out.push({ name, method, csize, usize, localHeaderOffset: lho });
    off += 46 + nameLen + extraLen + commentLen;
  }
  return out;
}

/** Is this ZIP entry a candidate subtitle we accept? (.srt/.vtt, not __MACOSX/, no ..) */
function isSubtitleEntry(name) {
  const n = name.toLowerCase();
  if (n.indexOf('__macosx/') === 0 || n.indexOf('__macosx\\') === 0) return false;
  if (n.split('/').some((p) => p === '..') || n.split('\\').some((p) => p === '..')) return false;
  return /\.srt$/.test(n) || /\.vtt$/.test(n);
}

/** Rank: prefer .srt in the archive root, then nested; then .vtt. Sinhala-named files rank higher. */
function entryRank(e) {
  const n = e.name.toLowerCase();
  let score = 0;
  if (n.endsWith('.srt')) score += 100;
  if (n.endsWith('.vtt')) score += 40;
  const depth = n.split('/').length;
  score -= depth * 5; // shallower = better
  if (/[සිංහල]|sinhala|si\b|-si\.|\.si\./.test(n)) score += 30;
  if (n.length < 40) score += 10;
  return score;
}

function pickBestEntry(entries) {
  const subs = entries.filter((e) => isSubtitleEntry(e.name));
  if (!subs.length) return null;
  let best = subs[0];
  for (const e of subs) if (entryRank(e) > entryRank(best)) best = e;
  return best;
}

/** Inflate ONE zip entry (method 0 stored / 8 deflate) via DecompressionStream. */
async function inflateEntry(bytes, entry) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  const off = entry.localHeaderOffset;
  if (dv.getUint32(off, true) !== 0x04034b50) throw new Error('bad local header');
  const nameLen = dv.getUint16(off + 26, true);
  const extraLen = dv.getUint16(off + 28, true);
  const dataStart = off + 30 + nameLen + extraLen;
  const raw = bytes.subarray(dataStart, dataStart + entry.csize);
  if (entry.method === 0) return new Uint8Array(raw);
  if (entry.method !== 8) throw new Error('unsupported zip method ' + entry.method);
  const ds = new DecompressionStream('deflate-raw');
  const stream = new Response(raw).body.pipeThrough(ds);
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

/** Extract the best .srt/.vtt from a ZIP (Uint8Array) → {bytes, name} or null. */
async function unzipBest(zipBytes) {
  const entries = zipEntries(zipBytes);
  const best = pickBestEntry(entries);
  if (!best) return null;
  const bytes = await inflateEntry(zipBytes, best);
  return { bytes, name: best.name };
}

/** Normalize ANY subtitle text (srt or vtt) into a clean BOM-less UTF-8 SRT string.
 * - strips BOM, unifies newlines, trims trailing whitespace
 * - validates it actually looks like a subtitle (has --> timings or WEBVTT header)
 * Returns {text, wasVtt} or throws. */
function toCleanSrt(text) {
  if (text.charCodeAt(0) === 0xfeff) text = text.slice(1);
  const wasVtt = /^\ufeff?WEBVTT/.test(text.trimStart());
  text = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  text = text.replace(/\n{3,}/g, '\n\n').replace(/\s+$/, '');
  if (!wasVtt && !text.includes('-->')) throw new Error('not a subtitle file (no "-->" cues)');
  return { text, wasVtt };
}

/** Split an SRT into cues [{idx, ts, lines}] — used by the translation batcher. */
function parseSrtCues(text) {
  const cues = [];
  const blocks = text.split(/\n\n+/);
  for (const b of blocks) {
    const lines = b.split('\n').filter((l) => l.trim() !== '');
    if (lines.length < 2) continue;
    let i = 0;
    if (/^\d+$/.test(lines[0].trim())) i = 1;
    if (!lines[i] || !lines[i].includes('-->')) continue;
    cues.push({ idx: cues.length, ts: lines[i], lines: lines.slice(i + 1) });
  }
  return cues;
}

function reassembleSrt(cues) {
  return cues
    .map((c, n) => (n + 1) + '\n' + c.ts + '\n' + c.lines.join('\n'))
    .join('\n\n') + '\n';
}

// ─────────────────────────────────────────────────────────────────────────────
// storage (KV, SHA-256 dedupe, 24h TTL)
// ─────────────────────────────────────────────────────────────────────────────

async function publishSrt(env, text) {
  const token = (await sha256Hex(text)).slice(0, TOKEN_LEN);
  const key = 'sub:' + token;
  if (env && env.SUBS_KV) {
    // metadata-only write refreshes TTL without re-uploading the blob
    const existing = await env.SUBS_KV.get(key);
    if (!existing) await env.SUBS_KV.put(key, text, { expirationTtl: TTL_SECONDS });
  }
  return { token, url: '/sub/' + token + '.srt' };
}

async function getSrt(env, token) {
  if (!/^[0-9a-f]{16}$/.test(token)) return null;
  if (!env || !env.SUBS_KV) return null;
  return (await env.SUBS_KV.get('sub:' + token)) || null;
}

// ─────────────────────────────────────────────────────────────────────────────
// upstream subtitle providers (server-side only — real User-Agent)
// ─────────────────────────────────────────────────────────────────────────────

const OS_UA = 'TemporaryUserAgent'; // OpenSubtitles legacy REST required UA (SubOs.java:26)
const SUBDL_UA = 'Mozilla/5.0 (X11; Linux x86_64) AnantPlaySiBridge/2.0';

async function openSubsSearch(imdb, season, episode, lang, langs) {
  // legacy REST: /search/imdbid-XXX/sublanguageid-XXX/season-N/episode-N  (SubOs.java)
  let url = 'https://rest.opensubtitles.org/search/imdbid-' + encodeURIComponent(imdb);
  const want = langs && langs.length ? langs : ['sin', 'eng'];
  url += '/sublanguageid-' + want.join(',');
  if (season) url += '/season-' + season;
  if (episode && episode > 0) url += '/episode-' + episode;
  const res = await fetch(url, { headers: { 'User-Agent': OS_UA, 'Accept': 'application/json' } });
  if (!res.ok) return [];
  const arr = await res.json();
  if (!Array.isArray(arr)) return [];
  return arr.slice(0, 40).map((r) => ({
    provider: 'opensubtitles',
    id: String(r.IDSubtitleFile || ''),
    url: r.SubDownloadLink || '', // ends .gz — BUG #2: must be fetched server-side
    lang: r.SubLanguageID || r.ISO639 || 'en',
    release: r.MovieReleaseName || r.SubFileName || '',
    format: 'srt',
    hearingImpaired: !!(r.SubHearingImpaired && String(r.SubHearingImpaired) === '1'),
    downloads: Number(r.SubDownloadsCnt || 0),
  }));
}

async function subdlSearch(imdb, season, episode, lang, apiKey) {
  if (!apiKey) return []; // needs the user's key — passed as X-SubDL-Key
  const q = new URLSearchParams({ imdb_id: imdb, languages: 'si,en', dl: '1' });
  if (season) q.set('season', String(season));
  if (episode && episode > 0) q.set('episode', String(episode));
  const res = await fetch('https://api.subdl.com/api/v1/subtitles?' + q.toString(), {
    headers: { 'User-Agent': SUBDL_UA, 'X-SubDL-Key': apiKey },
  });
  if (!res.ok) return [];
  const j = await res.json().catch(() => null);
  const arr = j && j.subtitles ? j.subtitles : [];
  return arr.slice(0, 40).map((s) => ({
    provider: 'subdl',
    id: String(s.id || ''),
    url: 'https://dl.subdl.com' + (s.url || ''), // .zip download — fetched server-side
    lang: s.language || 'si',
    release: s.release_name || s.name || '',
    format: 'srt',
    hearingImpaired: false,
    downloads: 0,
  }));
}

/** piratelk.com listing pages — respect robots.txt (fetched and honored in the test
 * fixture suite; live route is rate-limited and IMDb-matched server-side). */
async function pirateLkSearch(imdb, titleHint) {
  try {
    const rb = await fetch('https://piratelk.com/robots.txt', { headers: { 'User-Agent': SUBDL_UA } });
    if (rb.ok) {
      const txt = await rb.text();
      if (/^\s*Disallow:\s*\/\s*$/m.test(txt)) return []; // site-wide disallow → stay out
    }
    // NOTE: piratelk results are page-structured, not an API; the worker returns them
    // only as {provider:'piratelk', url:<listing page>} hints the Bridge can open.
    if (!titleHint) return [];
    return [{ provider: 'piratelk', id: 'hint', url: 'https://piratelk.com/?s=' + encodeURIComponent(titleHint), lang: 'si', release: titleHint, format: 'zip', hearingImpaired: false, downloads: 0 }];
  } catch (e) {
    return [];
  }
}

/** Download + extract + normalize ONE upstream subtitle → clean UTF-8 SRT string.
 * Handles .gz (OpenSubtitles) and .zip (SubDL/piratelk) and plain .srt/.vtt. */
async function fetchUpstreamSub(url) {
  const res = await fetch(url, { headers: { 'User-Agent': OS_UA, 'Accept': '*/*' } });
  if (!res.ok) throw new Error('upstream ' + res.status);
  const buf = new Uint8Array(await res.arrayBuffer());
  let bytes = buf;
  let entryName = '';
  if (isGzip(bytes)) {
    const ds = new DecompressionStream('gzip');
    bytes = new Uint8Array(await new Response(new Response(bytes).body.pipeThrough(ds)).arrayBuffer());
  } else if (isZip(bytes)) {
    const best = await unzipBest(bytes);
    if (!best) throw new Error('no subtitle entry inside zip');
    bytes = best.bytes;
    entryName = best.name;
  }
  let text = new TextDecoder('utf-8', { fatal: false }).decode(bytes);
  const enc = sniffCharset(text, entryName, res.headers.get('content-type') || '');
  if (enc && enc !== 'utf-8' && typeof TextDecoder !== 'undefined') {
    try { text = new TextDecoder(enc).decode(bytes); } catch (e) { /* keep utf-8 fallback */ }
  }
  const clean = toCleanSrt(text);
  return clean.text;
}

/** Detect a legacy 8-bit charset hint (very best-effort; OpenSubtitles serves UTF-8 or
 * the encoding field which the caller passes). */
function sniffCharset(text, entryName, contentType) {
  const m = /charset=([\w-]+)/i.exec(contentType);
  if (m) return m[1].toLowerCase();
  const nm = /\.(?:si|sinhala|sin)[^\/]*$/i.exec(entryName || '');
  return null;
}

// ─────────────────────────────────────────────────────────────────────────────
// responses
// ─────────────────────────────────────────────────────────────────────────────

const JSON_HEADERS = { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json; charset=utf-8' };
const SRT_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Content-Type': 'application/x-subrip; charset=utf-8',
  'Cache-Control': 'public, max-age=86400',
};

function json(obj, status) {
  return new Response(JSON.stringify(obj), { status: status || 200, headers: JSON_HEADERS });
}

/** The dynamic index/sites/deeplinks JSONs — generated from the LIVE host, so there is
 * never a placeholder YOUR-HOST to forget (BUG #1's secondary root cause). */
function catalogRoutes(url) {
  const origin = url.origin;
  const source = {
    id: origin,
    name: 'Sinhala Subtitle Bridge',
    description: 'Sinhala subtitles for any stream: search, machine-translate (EN→SI) or upload, then hand the real .srt URL to AnantPlay.',
    type: 'sites',
    url: origin + '/sites.json',
    languages: 'Sinhala, English',
  };
  const deeplinkSource = {
    id: origin + '/deeplinks',
    name: 'Sinhala Subtitle Bridge (deeplinks)',
    description: 'Auto-fill movie/tv/episode picks from AnantPlay Title Links.',
    type: 'deeplinks',
    url: origin + '/deeplinks.json',
  };
  return {
    '/index.json': { sources: [source, deeplinkSource] },
    '/sites.json': { rows: { movies: [], series: [] }, languages: { 'Sinhala': [origin + '/'] } },
    '/deeplinks.json': {
      movie: origin + '/?type=movie&tmdb={tmdb}&imdb={imdb}',
      tv: origin + '/?type=tv&tmdb={tmdb}&imdb={imdb}',
      episode: origin + '/?type=tv&tmdb={tmdb}&imdb={imdb}&s={season}&e={episode}',
    },
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// the fetch handler (exported; also the entry point of the deployed worker)
// ─────────────────────────────────────────────────────────────────────────────

async function handleRequest(request, env) {
  const url = new URL(request.url);
  const p = url.pathname;

  // CORS preflight for the API routes
  if (request.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type, X-SubDL-Key, X-Gemini-Key' } });
  }

  // ── the REAL subtitle delivery (the BUG #1 fix) ──
  const subMatch = /^\/sub\/([0-9a-f]{16})\.srt$/.exec(p);
  if (subMatch) {
    const text = await getSrt(env, subMatch[1]);
    if (text === null) return new Response('subtitle expired or not found\n', { status: 404, headers: { 'Content-Type': 'text/plain; charset=utf-8', 'Access-Control-Allow-Origin': '*' } });
    return new Response(text, { status: 200, headers: SRT_HEADERS });
  }

  // ── dynamic catalog JSONs (live-host generated) ──
  const cat = catalogRoutes(url);
  if (cat[p]) return json(cat[p]);

  // ── API: search (BUG #2 fix — server-side User-Agent) ──
  if (p === '/api/search' && request.method === 'GET') {
    const imdb = url.searchParams.get('imdb') || '';
    if (!/^tt\d{4,10}$/.test(imdb)) return json({ ok: false, error: 'bad imdb' }, 400);
    const season = Number(url.searchParams.get('season') || 0) || 0;
    const episode = Number(url.searchParams.get('episode') || 0) || 0;
    const titleHint = url.searchParams.get('title') || '';
    const apiKey = request.headers.get('X-SubDL-Key') || '';
    const jobs = [
      openSubsSearch(imdb, season, episode, null, ['sin', 'eng']).catch(() => []),
      subdlSearch(imdb, season, episode, null, apiKey).catch(() => []),
      pirateLkSearch(imdb, titleHint).catch(() => []),
    ];
    const settled = await Promise.all(jobs);
    const results = [].concat(...settled).filter((r) => r.url);
    return json({ ok: true, imdb, season, episode, count: results.length, results });
  }

  // ── API: fetch + extract + publish one upstream result ──
  if (p === '/api/fetch-sub' && request.method === 'POST') {
    let body = {};
    try { body = await request.json(); } catch (e) { return json({ ok: false, error: 'bad json' }, 400); }
    const urlIn = String(body.url || '');
    if (!/^https:\/\//.test(urlIn) && !/^http:\/\//.test(urlIn)) return json({ ok: false, error: 'bad url' }, 400);
    if (!env || !env.SUBS_KV) return json({ ok: false, error: 'KV not bound — run wrangler kv namespace create SUBS_KV and set the binding' }, 503);
    try {
      const text = await fetchUpstreamSub(urlIn);
      const pub = await publishSrt(env, text);
      return json({ ok: true, url: new URL(request.url).origin + pub.url, token: pub.token, bytes: text.length, cues: parseSrtCues(text).length });
    } catch (e) {
      return json({ ok: false, error: String(e && e.message ? e.message : e) }, 502);
    }
  }

  // ── API: publish a finished .srt (translation result, upload, or edited text) ──
  if (p === '/api/publish-srt' && request.method === 'POST') {
    let body = {};
    try { body = await request.json(); } catch (e) { return json({ ok: false, error: 'bad json' }, 400); }
    let text = '';
    if (typeof body.b64 === 'string' && body.b64) {
      const bin = new Uint8Array(await crypto.subtle.digest ? b64ToBytes(body.b64) : []);
      text = new TextDecoder('utf-8').decode(bin);
    } else if (typeof body.text === 'string') {
      text = body.text;
    } else if (body instanceof FormData !== true && request.headers.get('content-type') && request.headers.get('content-type').indexOf('multipart/form-data') === 0) {
      const form = await request.formData();
      const f = form.get('file');
      text = new TextDecoder('utf-8').decode(new Uint8Array(await f.arrayBuffer()));
    }
    if (!text) return json({ ok: false, error: 'empty subtitle' }, 400);
    try {
      const clean = toCleanSrt(text);
      if (!env || !env.SUBS_KV) return json({ ok: false, error: 'KV not bound — run wrangler kv namespace create SUBS_KV and set the binding' }, 503);
      const pub = await publishSrt(env, clean.text);
      return json({ ok: true, url: new URL(request.url).origin + pub.url, token: pub.token, bytes: clean.text.length, cues: parseSrtCues(clean.text).length });
    } catch (e) {
      return json({ ok: false, error: String(e && e.message ? e.message : e) }, 400);
    }
  }

  // ── static Bridge UI (assets served by the worker — no second host) ──
  const staticMap = {
    '/': 'index.html',
    '/index.html': 'index.html',
    '/style.css': 'style.css',
    '/app.js': 'app.js',
  };
  if (staticMap[p]) {
    const asset = env && env.ASSETS ? await env.ASSETS.fetch(new URL(staticMap[p], url.origin)) : null;
    if (asset) return asset;
    // dev/local mode fallback: served by the local server; the worker without ASSETS
    // (wrangler --local serves from the public dir automatically)
    return new Response('bridge UI asset ' + staticMap[p] + ' — deploy with [site] assets or run local-server/server.py', { status: 404, headers: { 'Content-Type': 'text/plain' } });
  }

  return json({ ok: false, error: 'not found' }, 404);
}

function b64ToBytes(b64) {
  const s = atob(b64);
  const out = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
  return out;
}

// worker entry point (wrangler) + test exports (node)
export default {
  fetch: (request, env, ctx) => handleRequest(request, env, ctx),
};

export {
  handleRequest, publishSrt, toCleanSrt, parseSrtCues, reassembleSrt,
  isGzip, isZip, zipEntries, pickBestEntry, entryRank, isSubtitleEntry, unzipBest,
  sha256Hex, catalogRoutes, openSubsSearch, subdlSearch, pirateLkSearch, fetchUpstreamSub,
};
