/* Sinhala Subtitle Bridge — app.js (TV D-pad navigable, zero hardcoded pirate URLs). */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var state = { loadedSrt: null, deliveredUrl: null, token: null };

  // ── deeplink auto-fill (BUG #3): ?type=&tmdb=&imdb=&s=&e= ──────────────────
  function applyDeeplink() {
    var q = new URLSearchParams(location.search);
    var touched = false;
    ['type', 'tmdb', 'imdb', 's', 'e'].forEach(function (k) {
      if (!q.get(k)) return;
      touched = true;
      if (k === 'type') $('type').value = q.get('type') === 'movie' ? 'movie' : 'tv';
      if (k === 'tmdb') $('tmdb').value = q.get('tmdb');
      if (k === 'imdb') $('imdb').value = q.get('imdb');
      if (k === 's') $('season').value = q.get('s');
      if (k === 'e') $('episode').value = q.get('e');
    });
    if (!touched) return;
    $('resolveMsg').textContent = 'AnantPlay deeplink detected — auto-filling…';
    resolveFromCinemeta();
    searchSubs(); // zero typing: auto-search immediately
  }

  // ── Cinemeta resolve (tmdb → imdb / title) ─────────────────────────────────
  function resolveFromCinemeta() {
    var tmdb = $('tmdb').value.trim();
    var imdb = $('imdb').value.trim();
    var type = $('type').value;
    if (!tmdb && !imdb) { $('resolveMsg').textContent = 'IMDb හෝ TMDB එකක් ලියන්න.'; return; }
    var url = 'https://v3-cinemeta.strem.io/' + (type === 'movie' ? 'movie' : 'series') + '/' + (imdb || 'tmdb:' + tmdb) + '.json';
    fetch(url).then(function (r) { return r.ok ? r.json() : null; }).then(function (j) {
      if (!j || !j.meta) { $('resolveMsg').textContent = 'Cinemeta හිට නොහමු වුණා — නම අතින් ලියන්න.'; return; }
      var m = j.meta;
      if (m.imdb_id && !imdb) $('imdb').value = m.imdb_id;
      if (m.name) $('title').value = m.name;
      $('resolveMsg').textContent = '✔ ' + (m.name || '') + (m.year ? ' (' + m.year + ')' : '') + ' — Cinemeta';
    }).catch(function () {
      $('resolveMsg').textContent = 'Cinemeta offline — fields එක අතින් සම්පූර්ණ කරන්න.';
    });
  }

  // ── search ──────────────────────────────────────────────────────────────────
  function searchSubs() {
    var imdb = $('imdb').value.trim();
    if (!/^tt\d{4,10}$/.test(imdb)) {
      $('searchMsg').textContent = 'IMDb id එක අවශ්‍යයි (e.g. tt1234567) — Resolve බොත්තම එය ලබා දේ.';
      $('results').hidden = false;
      return;
    }
    $('results').hidden = false;
    $('resultList').innerHTML = '<p class="hint">සොයමින්… (OpenSubtitles + SubDL + piratelk)</p>';
    var q = '/api/search?imdb=' + encodeURIComponent(imdb) +
      '&season=' + encodeURIComponent($('season').value || 0) +
      '&episode=' + encodeURIComponent($('episode').value || 0) +
      ($('title').value.trim() ? '&title=' + encodeURIComponent($('title').value.trim()) : '');
    fetch(q, { headers: { 'X-SubDL-Key': $('subdlKey').value.trim() } })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (!j.ok || !j.results.length) {
          $('resultList').innerHTML = '<p class="hint">ප්‍රතිඵල නැහැ — EN subtitle එකක් තෝරලා 3 වන කොටසින් සිංහලට පරිවර්තනය කරන්න.</p>';
          return;
        }
        $('resultList').innerHTML = '';
        j.results.forEach(function (r) {
          var row = document.createElement('button');
          row.className = 'result-row';
          row.setAttribute('role', 'option');
          row.textContent = '[' + r.provider + '] ' + r.lang + ' · ' + (r.release || '—') + (r.hearingImpaired ? ' · SDH' : '');
          row.onclick = function () { fetchSub(r.url, row); };
          $('resultList').appendChild(row);
        });
        $('searchMsg').textContent = j.count + ' results.';
      })
      .catch(function () { $('searchMsg').textContent = 'සෙවීම අසාර්ථකි — නැවත උත්සාහ කරන්න.'; });
  }

  // ── fetch + extract + publish one result → REAL .srt URL ────────────────────
  function fetchSub(upstreamUrl, rowEl) {
    if (rowEl) rowEl.disabled = true;
    fetch('/api/fetch-sub', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: upstreamUrl }),
    })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (rowEl) rowEl.disabled = false;
        if (!j.ok) { $('searchMsg').textContent = 'ගෙන ඒම අසාර්ථකි: ' + j.error; return; }
        state.deliveredUrl = j.url;
        state.token = j.token;
        $('delivered').hidden = false;
        $('srtLink').href = j.url;
        $('srtLink').textContent = j.url;
        $('deliveredMsg').textContent = '✔ ' + j.cues + ' cues · ' + j.bytes + ' bytes · HTTP 200 .srt';
        fetch(j.url, { cache: 'no-store' }).then(function (r) {
          return r.ok ? r.text() : '';
        }).then(function (t) { if (t) { state.loadedSrt = t; $('translate').classList.add('ready'); } });
        $('delivered').scrollIntoView({ behavior: 'smooth', block: 'center' });
      })
      .catch(function (e) { $('searchMsg').textContent = 'ජාලය: ' + e; });
  }

  // ── upload .srt/.zip/.gz → publish ──────────────────────────────────────────
  function uploadFile() {
    var f = $('fileInput').files && $('fileInput').files[0];
    if (!f) { $('uploadMsg').textContent = 'ගොනුවක් තෝරන්න.'; return; }
    var fr = new FileReader();
    fr.onload = function () {
      var b64 = btoa(String.fromCharCode.apply(null, new Uint8Array(fr.result)));
      fetch('/api/publish-srt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ b64: b64, name: f.name }),
      })
        .then(function (r) { return r.json(); })
        .then(function (j) {
          if (!j.ok) { $('uploadMsg').textContent = 'අසාර්ථකි: ' + j.error; return; }
          state.deliveredUrl = j.url; state.token = j.token;
          $('delivered').hidden = false;
          $('srtLink').href = j.url; $('srtLink').textContent = j.url;
          $('deliveredMsg').textContent = '✔ ' + j.cues + ' cues · uploaded';
          $('uploadMsg').textContent = 'Uploaded ✔';
        });
    };
    fr.readAsArrayBuffer(f);
  }

  // ── Gemini EN→SI timestamp-locked batch translation ───────────────────────────
  function translateLoaded() {
    if (!state.loadedSrt) { $('translateMsg').textContent = 'පළමුව 2 කොටසින් subtitle එකක් ගන්න (හෝ upload කරන්න).'; return; }
    var key = $('geminiKey').value.trim();
    if (!key) { $('translateMsg').textContent = 'Gemini key එකක් අවශ්‍යයි (aistudio.google.com — නොමිලේ).'; return; }
    var cues = parseCues(state.loadedSrt);
    var BATCH = 250;
    var out = [];
    var idx = 0;
    $('translateMsg').textContent = 'පරිවර්තනය ආරම්භ… (' + cues.length + ' cues, ' + Math.ceil(cues.length / BATCH) + ' batches)';

    function nextBatch() {
      if (idx >= cues.length) {
        var srt = cues
          .map(function (c, n) { return (n + 1) + '\n' + c.ts + '\n' + (out[c.idx] || c.lines.join('\n')); })
          .join('\n\n') + '\n';
        fetch('/api/publish-srt', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: srt }),
        })
          .then(function (r) { return r.json(); })
          .then(function (j) {
            if (!j.ok) { $('translateMsg').textContent = 'publish අසාර්ථකි: ' + j.error; return; }
            state.deliveredUrl = j.url; state.token = j.token;
            $('delivered').hidden = false;
            $('srtLink').href = j.url; $('srtLink').textContent = j.url;
            $('deliveredMsg').textContent = '✔ සිංහල පරිවර්තනය සම්පූර්ණ — ' + j.cues + ' cues';
            $('translateMsg').textContent = '✔ සිංහල .srt URL එක සූදානම්!';
            fetch(j.url, { cache: 'no-store' }).then(function (r) { return r.text(); }).then(function (t) { state.loadedSrt = t; });
          });
        return;
      }
      var batch = cues.slice(idx, idx + BATCH);
      var prompt = 'You are a professional English→Sinhala subtitle translator. Translate ONLY the text lines to natural Sinhala. Keep the cue numbers and timestamp lines EXACTLY as given. Reply with the SAME cue-number lines and timestamps, only the text translated. Do not merge, split, reorder or drop cues.\n\n';
      var body = batch.map(function (c) { return c.idx + '\n' + c.ts + '\n' + c.lines.join('\n'); }).join('\n\n');
      fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=' + encodeURIComponent(key), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt + body }] }],
          generationConfig: { temperature: 0.1 },
        }),
      })
        .then(function (r) { return r.json(); })
        .then(function (j) {
          var text = j && j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts && j.candidates[0].content.parts[0] ? j.candidates[0].content.parts[0].text : '';
          var got = parseCues(text);
          var nOk = 0;
          got.forEach(function (g) {
            var orig = cues.filter(function (c) { return c.idx === g.idx; })[0];
            if (orig && orig.ts === g.ts) { out[g.idx] = g.lines.join('\n'); nOk++; }
          });
          idx += BATCH;
          $('translateMsg').textContent = 'batch ' + Math.min(idx, cues.length) + '/' + cues.length + ' · ' + nOk + ' cues timestamp-validated';
          nextBatch();
        })
        .catch(function (e) { $('translateMsg').textContent = 'Gemini: ' + e + ' — batch එක නැවත උත්සාහ කරන්න.'; });
    }
    nextBatch();
  }

  function parseCues(text) {
    var cues = [];
    String(text).split(/\n\n+/).forEach(function (b) {
      var lines = b.split('\n').filter(function (l) { return l.trim() !== ''; });
      if (lines.length < 2) return;
      var i = /^\d+$/.test(lines[0].trim()) ? 1 : 0;
      if (!lines[i] || lines[i].indexOf('-->') < 0) return;
      cues.push({ idx: cues.length, ts: lines[i], lines: lines.slice(i + 1) });
    });
    return cues;
  }

  // ── stream handoff modes ─────────────────────────────────────────────────────
  var MUX_DEMO = 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8'; // public-domain HLS test stream

  function handoff(url) {
    // The location of this page is the AnantPlay-embedded WebView; navigating the whole
    // page straight to the media URL triggers the Sniffer handoff (decide() →
    // shouldOverrideUrlLoading → PlayerActivity). Subtitles captured earlier ride along.
    location.href = url;
  }

  function loadEmbed() {
    var tpl = $('embedTemplate').value.trim();
    if (!tpl) { return; }
    try { localStorage.setItem('si-bridge-embed', tpl); } catch (e) {}
    var stream = $('streamUrl').value.trim() || MUX_DEMO;
    var url = tpl.replace('{STREAM}', encodeURIComponent(stream));
    var f = $('embedFrame');
    f.hidden = false;
    f.src = url;
  }

  // ── wiring ───────────────────────────────────────────────────────────────────
  document.addEventListener('DOMContentLoaded', function () {
    $('btnResolve').onclick = resolveFromCinemeta;
    $('btnSearch').onclick = searchSubs;
    $('btnTranslate').onclick = translateLoaded;
    $('btnUpload').onclick = uploadFile;
    $('btnFetchIt').onclick = function () {
      if (!state.deliveredUrl) return;
      // REAL network fetch: WebView shouldInterceptRequest (WebActivity.java:443) sees
      // this genuine request → Sniffer.request() captures the .srt → rides with the stream.
      fetch(state.deliveredUrl, { cache: 'no-store' })
        .then(function (r) { return r.text(); })
        .then(function (t) { state.loadedSrt = t; $('deliveredMsg').textContent += ' · fetched for Sniffer'; });
    };
    $('btnCopy').onclick = function () {
      if (!state.deliveredUrl) return;
      navigator.clipboard && navigator.clipboard.writeText(state.deliveredUrl);
      $('deliveredMsg').textContent += ' · copied';
    };
    $('btnPlayStream').onclick = function () {
      var u = $('streamUrl').value.trim();
      if (!/^https?:\/\//.test(u)) { $('streamUrl').focus(); return; }
      handoff(u);
    };
    $('btnMuxDemo').onclick = function () { $('streamUrl').value = MUX_DEMO; handoff(MUX_DEMO); };
    $('btnEmbed').onclick = loadEmbed;
    try { var saved = localStorage.getItem('si-bridge-embed'); if (saved) $('embedTemplate').value = saved; } catch (e) {}

    // TV D-pad: focus ring visible on every interactive element; Enter activates.
    Array.prototype.forEach.call(document.querySelectorAll('button, input, select, a, .result-row'), function (el) {
      el.setAttribute('tabindex', el.tagName === 'BUTTON' || el.classList.contains('result-row') ? '0' : '-1');
    });

    applyDeeplink();
  });
})();
